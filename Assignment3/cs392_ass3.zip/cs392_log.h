/* 
 * Name: Eric Altenburg
 * Date: 20 November 2019
 * Course: CS-392
 * Pledge: I pledge my honor that I have abided by the Stevens Honor System.
 */

#ifndef CS392_LOG_H
#define CS392_LOG_H

#include <stdio.h>

void write_to_file(char *);

#endif